import { Card, CardHeader, CardBody, Button, CardTitle, CardText, CardSubtitle, CardImg } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import User from './pages/user';
import Header from './components/header';

function App() {
    return (
            <User/>

    );
}

export default App;
