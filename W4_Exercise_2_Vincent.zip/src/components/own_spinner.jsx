import './my_spinner.css'

export default function MySpinner(){
    return(
        <div class="loader"></div>
    )
}